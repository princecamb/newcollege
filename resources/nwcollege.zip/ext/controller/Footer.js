sap.ui.define(["sap/m/MessageToast"],function(e){"use strict";return{footer_meth:function(s){e.show("Custom handler invoked.")}}});
//# sourceMappingURL=Footer.js.map