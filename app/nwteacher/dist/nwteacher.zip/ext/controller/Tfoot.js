sap.ui.define(["sap/m/MessageToast"],function(t){"use strict";return{tfoot_meth:function(e){t.show("Custom handler invoked.")}}});
//# sourceMappingURL=Tfoot.js.map